﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyTrafficLight
{
    class Bulb
    {
        private ConsoleColor color;
        private string bulb;
        private bool on;

        public ConsoleColor Color
        {
            get
            {
                return color;
            }
        }

        public bool On
        {
            get
            {
                return on;
            }

            set
            {
                on = value;
            }
        }

        public Bulb() {

        }

        public Bulb(ConsoleColor color) {
            this.color = color;
            this.bulb = "***\n****\n*****\n****\n***";
        }

        public void showBulb() {
            if(this.on)
                Console.ForegroundColor = this.color;
            Console.WriteLine(this.bulb);
            Console.ResetColor();
        }
    }
}
