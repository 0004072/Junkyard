﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyTrafficLight
{
    class Light
    {
        private Bulb[] bulbs;
        private LightCombination[] lightOrder;
        private int combinationToShow;

        public Light() {
            this.combinationToShow = 0;
            bulbs = new Bulb[3] { new Bulb(ConsoleColor.Red), new Bulb(ConsoleColor.Yellow), new Bulb(ConsoleColor.Green) };

            LightCombination halt = new LightCombination(new int[] { 0 }, 10);
            LightCombination set = new LightCombination(new int[] { 0, 1}, 3);
            LightCombination go = new LightCombination(new int[] { 2 }, 10);
            LightCombination wait = new LightCombination(new int[] { 1 }, 3);
            lightOrder = new LightCombination[] { halt, set, go, wait };
        }

        public void trunCombination()
        {
            Console.Clear();

            LightCombination nextCombination = lightOrder[combinationToShow];

            shutOffAllBulbs();
            setLightCombination(nextCombination);
            showLightCombination();

            System.Threading.Thread.Sleep(nextCombination.TimeOnFor * 1000);
            combinationToShow++;
            if (combinationToShow == 4)
                combinationToShow = 0;
        }

        private void setLightCombination(LightCombination nextPattern)
        {
            foreach (int bulbOn in nextPattern.BulbsOn)
            {
                bulbs[bulbOn].On = true;
            }
        }

        private void showLightCombination()
        {
            foreach (Bulb b in this.bulbs)
            {
                b.showBulb();
                Console.WriteLine();
            }
        }

        private void shutOffAllBulbs() {
            foreach (Bulb b in this.bulbs)
            {
                b.On = false;
            }
        }
    }
}
