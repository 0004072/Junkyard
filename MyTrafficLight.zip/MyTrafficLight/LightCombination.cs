﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyTrafficLight
{
    class LightCombination
    {
        private int[] bulbsOn;
        private int timeOnFor;

        public LightCombination(int[] bulbsOn, int timeOnFor)
        {
            this.bulbsOn = bulbsOn;
            this.timeOnFor = timeOnFor;
        }

        public int[] BulbsOn
        {
            get
            {
                return bulbsOn;
            }
        }

        public int TimeOnFor
        {
            get
            {
                return timeOnFor;
            }
        }
    }
}
